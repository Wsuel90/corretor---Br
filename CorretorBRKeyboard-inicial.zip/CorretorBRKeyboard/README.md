# Corretor BR Keyboard

Projeto Android inicial de teclado (IME) em português brasileiro.

## Estado desta versão
- Teclado Android instalável como método de entrada.
- Interface escura com identidade visual Corretor BR.
- Processamento local: não faz chamadas de rede.
- Pequeno conjunto inicial de substituições comuns ao pressionar espaço.

**Importante:** esta é uma versão experimental. A correção offline ainda é limitada e não equivale a um corretor ortográfico completo. O próximo passo é integrar um dicionário pt-BR offline (por exemplo, Hunspell) e melhorar sugestões, acentuação e pontuação.

## Compilar
O workflow GitHub Actions em `.github/workflows/build-apk.yml` compila `app-debug.apk` quando executado manualmente ou após um push na branch `main`.
