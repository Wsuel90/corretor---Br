package br.com.corretorbr.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputConnection
import android.widget.LinearLayout
import android.widget.TextView

class CorretorInputMethodService : InputMethodService() {
    private var shift = true
    private var suggestionBar: LinearLayout? = null
    private var keyboard: LinearLayout? = null
    private val typed = StringBuilder()

    // Dicionário inicial pequeno e totalmente local. Será ampliado com um léxico pt-BR.
    private val corrections = mapOf(
        "vc" to "você", "vcs" to "vocês", "pq" to "porque", "tb" to "também",
        "nao" to "não", "ta" to "está", "to" to "estou", "q" to "que",
        "eh" to "é", " agente" to " a gente", "concerteza" to "com certeza",
        "derrepente" to "de repente", "mais" to "mais", " jente" to " gente",
        "voce" to "você", "tambem" to "também", "obrigadoo" to "obrigado",
        "ola" to "olá", "bomdia" to "bom dia", "boatarde" to "boa tarde",
        "boanoite" to "boa noite", " hj" to " hoje"
    )

    override fun onCreateInputView(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 8, 4, 8)
            background = rounded(0xFF10131B.toInt(), 18)
        }
        suggestionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        outer.addView(suggestionBar, LinearLayout.LayoutParams(-1, dp(42)))
        keyboard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outer.addView(keyboard, LinearLayout.LayoutParams(-1, -2))
        buildRows()
        showSuggestions("")
        return outer
    }

    private fun buildRows() {
        val root = keyboard ?: return
        root.removeAllViews()
        addRow(root, listOf("q","w","e","r","t","y","u","i","o","p"))
        addRow(root, listOf("a","s","d","f","g","h","j","k","l"))
        addRow(root, listOf("⇧","z","x","c","v","b","n","m","⌫"))
        addRow(root, listOf("?123",",","☺","espaço",".","↵"))
    }

    private fun addRow(parent: LinearLayout, keys: List<String>) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        keys.forEach { key ->
            val weight = if (key in listOf("?123","⇧","⌫","↵","espaço","☺")) 1.45f else 1f
            val tv = TextView(this).apply {
                text = if (key.length == 1 && key[0].isLetter() && shift) key.uppercase() else if (key == "espaço") "Português" else key
                textSize = if (key.length > 1) 12f else 20f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT
                background = rounded(if (key in listOf("⇧","⌫","↵","?123")) 0xFF34445E.toInt() else 0xFF283244.toInt(), 8)
                setOnClickListener { handleKey(key) }
            }
            val lp = LinearLayout.LayoutParams(0, dp(48), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            row.addView(tv, lp)
        }
        parent.addView(row, LinearLayout.LayoutParams(-1, -2))
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⌫" -> {
                ic.deleteSurroundingText(1, 0)
                if (typed.isNotEmpty()) typed.deleteCharAt(typed.length - 1)
            }
            "⇧" -> { shift = !shift; buildRows(); return }
            "↵" -> { ic.commitText("\n", 1); typed.clear() }
            "espaço" -> {
                val word = typed.toString().lowercase()
                val replacement = corrections[word]
                if (replacement != null) {
                    ic.deleteSurroundingText(typed.length, 0)
                    ic.commitText(if (typed.firstOrNull()?.isUpperCase() == true) replacement.replaceFirstChar { it.uppercase() } else replacement, 1)
                }
                ic.commitText(" ", 1)
                typed.clear()
            }
            "?123" -> { showSuggestions("123"); return }
            "☺" -> { ic.commitText("😊", 1) }
            else -> {
                val ch = if (key.length == 1 && key[0].isLetter() && shift) key.uppercase() else key
                ic.commitText(ch, 1)
                if (ch.length == 1 && ch[0].isLetter()) typed.append(ch)
                shift = false
            }
        }
        buildRows()
        showSuggestions(typed.toString())
    }

    private fun showSuggestions(word: String) {
        val bar = suggestionBar ?: return
        bar.removeAllViews()
        val candidate = corrections[word.lowercase()]
        val labels = listOf(if (word.isBlank()) "Corretor BR" else word) + listOfNotNull(candidate) + listOf("•")
        labels.forEach { label ->
            val item = TextView(this).apply {
                text = label
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(if (label == candidate) 0xFF8DE0B7.toInt() else 0xFFEAF1FC.toInt())
                setOnClickListener {
                    if (candidate != null && label == candidate) {
                        currentInputConnection?.deleteSurroundingText(word.length, 0)
                        currentInputConnection?.commitText(candidate, 1)
                        typed.clear()
                        showSuggestions("")
                    }
                }
            }
            bar.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
