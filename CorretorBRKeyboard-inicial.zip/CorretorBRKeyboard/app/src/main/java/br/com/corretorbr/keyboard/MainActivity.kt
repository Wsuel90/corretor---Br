package br.com.corretorbr.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(0xFF10131B.toInt())
        }
        val title = TextView(this).apply {
            text = "Corretor BR"
            textSize = 28f
            setTextColor(0xFFF1F4FA.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Teclado em português brasileiro • funcionamento offline"
            textSize = 15f
            setTextColor(0xFFB8C4D8.toInt())
            setPadding(0, 12, 0, 28)
        }
        val enable = Button(this).apply {
            text = "1. Ativar teclado"
            setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val choose = Button(this).apply {
            text = "2. Selecionar Corretor BR"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        }
        val note = TextView(this).apply {
            text = "Versão inicial: teclado básico e correções locais de erros comuns. Não envia o que você digita para a internet. A correção ainda é limitada e será ampliada nas próximas versões."
            textSize = 14f
            setTextColor(0xFFB8C4D8.toInt())
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title); layout.addView(subtitle); layout.addView(enable); layout.addView(choose); layout.addView(note)
        setContentView(layout)
    }
}
